import librosa
import librosa.display
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from scipy import signal
from scipy.signal import butter, filtfilt, find_peaks

def audio_preprocess(file, SR=44100, FRAME_LEN=4410, HOP=2205):
    y, sr = librosa.load(file, sr=SR, mono=True, offset=0.0, duration=None)
    # remove DC component
    y = y - np.mean(y)
    # remove the silence parts at the beginning and end
    yt, index = librosa.effects.trim(y, frame_length=FRAME_LEN, hop_length=HOP)  # remove the silent regions
    yt_n = yt / np.max(np.abs(yt))  # normolized the sound
    return yt_n

def plot_time(sig, fs, title):
    tt = np.arange(len(sig)) / fs
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(tt, sig)
    ax.set_xlabel('Time/s', fontsize=16)
    ax.set_ylabel('Amplitude', fontsize=16)
    ax.set_title(title, fontsize=18, fontweight='bold')
    ax.tick_params(axis='both', labelsize=14, top=False, right=False)
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    plt.tight_layout()
    return fig, ax

def butter_lowpass_filter(data, cutoff_freq, fs, order=4):
    nyq_freq = 0.5*fs
    normal_cutoff = float(cutoff_freq) / nyq_freq
    b, a = butter(order, normal_cutoff, btype='lowpass')
    y = filtfilt(b, a, data)
    return y
def bandpass_filter(data, low_cutoff=50, high_cutoff=4000, sampling_rate=44100, order =4 ):
    nyquist = 0.5 * sampling_rate
    low = low_cutoff / nyquist
    high = high_cutoff / nyquist
    b, a = butter(order, [low, high], btype='band')
    filtered_signal = filtfilt(b, a, data)
    return filtered_signal#, b, a

def butter_lowpass_filter(data, cutoff_freq, fs, order=4):
    nyq_freq = 0.5*fs
    normal_cutoff = float(cutoff_freq) / nyq_freq
    b, a = butter(order, normal_cutoff, btype='lowpass')
    y = filtfilt(b, a, data)
    return y
# =====================
def plot_spec(sig, fs, nfft, ylim):
    # Compute spectrogram
    spectrogram = librosa.amplitude_to_db(librosa.stft(sig, nfft), ref=np.max)
    fig, ax = plt.subplots(figsize=(10, 6))
    librosa.display.specshow(spectrogram, sr=fs, x_axis='time', y_axis='linear', cmap='magma')
    rect = patches.Rectangle([5.9, 300], 1, 2800, linewidth=3, edgecolor='k', facecolor='none')
    ax.add_patch(rect)
    ax.text(4.5, 3300, 'Inhalation', fontsize=16, verticalalignment='center', color='r')
    rect = patches.Rectangle([6.9, 300], 1, 2800, linewidth=3, edgecolor='k', facecolor='none')
    ax.add_patch(rect)
    ax.text(7.5, 3300, 'Exhalation', fontsize=16, verticalalignment='center', color='r')
    plt.colorbar(format='%+2.0f dB')
    ax.set_xlabel('Time/s', fontsize=16)
    ax.set_ylabel('Frequency', fontsize=16)
    ax.set_title('Step 1: Spectrogram', fontsize=18, fontweight='bold')
    ax.tick_params(axis='both', labelsize=14, top=False, right=False)
    ax.spines['right'].set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.set_ylim([ylim[0], ylim[1]])
    plt.tight_layout()
    plt.show()

class EnvelopeFollower:
    def __init__(self):
        self.e_mem = 0

    def follow(self, x, scale):
        diff = x - self.e_mem
        if diff < 0:
            diff *= scale
        self.e_mem += diff
        return self.e_mem

#======================================= Section 1 ============================================================
# This is the section to test the sample frequency of the signal
# filename = ['tingheavy5.5.wav','tingheavy6.wav',
#             'tingheavy8.wav','tingheavy14.wav',
#             'tingheavy16.5.wav']

# ====================== Section 0: Parameter defination ============================================================

tur = 16 #ground truth of breathing rate per minite: BRP
file = 'demo.wav'
SR = 48000 # sample frequency
FRAME_LEN = int(SR / 10)  # 100 ms
HOP = int(FRAME_LEN / 2)  # 50%overlap, 5ms
win = 30 * SR #window length for processing

# ====================== Section 1: Read and pre-process raw audio ============================================================
sig = audio_preprocess(file, SR=SR, FRAME_LEN= FRAME_LEN, HOP = HOP)
# Plot the original waveform
_,_ = plot_time(sig, SR, 'Raw audio')
plt.show()

# ====================== Section 2: Breathing sound filtering ============================================================
# Filter the audio sound using bandpass filter to only preserve the breathing sound frequencies
order = 4
low = 600
high = 3000

fsig_win = bandpass_filter(sig, low, high, SR, order)*10
## visilisation
_, ax = plot_time(fsig_win, SR, 'Step 1: Filtered breathing sound')
ax.arrow(11, 0.8, -2.5, -0.2, head_width=0.1, head_length=0.3, fc='red', ec='red')
ax.text(8, 1, 'Motion artefacts', fontsize=16, verticalalignment='center',color='red')
ax.arrow(23, 0.5, -2, -0.35, head_width=0.1, head_length=0.3, fc='red', ec='red')
ax.text(20, 0.6, 'Breathing envelop', fontsize=16, verticalalignment='center', color='red')
rect = patches.Rectangle([12, -0.2], 1.6, 0.4, linewidth=1, edgecolor='m', facecolor='none')
ax.add_patch(rect)
ax.arrow(11, -0.6, 1.5, 0.3, head_width=0.1, head_length=0.3, fc='m', ec='m')
ax.text(10, -0.7, 'Inhalation', fontsize=16, verticalalignment='center', color='m')
rect = patches.Rectangle([14, -0.2], 1.8, 0.4, linewidth=1, edgecolor='m', facecolor='none')
ax.add_patch(rect)
ax.arrow(17, -0.6, -1.5, 0.3, head_width=0.1, head_length=0.3, fc='m', ec='m')
ax.text(16, -0.7, 'Exhalation', fontsize=16, verticalalignment='center', color='m')
plt.show()

## Plot spectrogram
plot_spec(fsig_win, SR, int(2048*2),[0,5000])

# ====================== Section 3: Envelop detetion ============================================================
envelope_follower = EnvelopeFollower()
scale = 0.01
## envelop detection
amplitude_envelope = [envelope_follower.follow(x, scale) for x in fsig_win]
amplitude_envelope = butter_lowpass_filter(amplitude_envelope, 40, SR, order) * 10
amplitude_envelope = amplitude_envelope[::int(np.ceil(SR/80))]
SR1 = 80
yhat= bandpass_filter(amplitude_envelope, 0.1, 10, SR1, order) * 10
kernel = int(SR1*0.5)
yhat = signal.medfilt(yhat, kernel_size=kernel + 1)

## Visilisatio
fig, ax = plt.subplots(figsize=(10, 6))
plt.plot(np.arange(len(fsig_win))/SR, fsig_win, label='breathing audio')
plt.plot(np.arange(len(yhat)) / SR1, yhat / 10 + 0.05, label='breathing envelop', linewidth=3, color = 'black')
ax.set_xlabel('Time/s', fontsize=16)
ax.set_ylabel('Amplitude', fontsize=16)
ax.set_title('Step 2&3: Downsampling & Envelop estimation', fontsize=18, fontweight='bold')
ax.tick_params(axis='both', labelsize=14, top=False, right=False)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
plt.tight_layout()
plt.legend(fontsize=16)
plt.show()

# ====================== Section 4: Peak detetion ============================================================
peaks, _ = find_peaks(yhat, height=0.5*np.mean(yhat), distance=SR1)#, width=200, prominence=0.2)
peaks = np.array([id for id, pk in zip(peaks, yhat[peaks]) if pk > 0.5*np.mean(yhat)])
## Visilisation
fig, ax = plt.subplots(figsize=(10, 6))
plt.plot(np.arange(len(fsig_win))/SR, fsig_win, label='breathing audio')
plt.plot(np.arange(len(yhat)) / SR1, yhat / 10 + 0.05, label='breathing envelop', linewidth=3, color='black')
plt.plot(peaks / SR1, yhat[peaks] / 10 + 0.05, "rx", markersize=20, label='peaks')
rect = patches.Rectangle([11.8, -0.2], 4, 0.6, linewidth=2, edgecolor='m', facecolor='none')
ax.add_patch(rect)
ax.arrow(15, -0.5, -1.5, 0.25, head_width=0.1, head_length=0.3, fc='m', ec='m')
ax.text(15, -0.7, 'Respiratory cycle', fontsize=16, verticalalignment='center', color='m')
ax.set_xlabel('Time/s', fontsize=16)
ax.set_ylabel('Amplitude', fontsize=16)
ax.set_title('Step 4: Peak Estimation', fontsize=18, fontweight='bold')
ax.tick_params(axis='both', labelsize=14, top=False, right=False)
ax.spines['right'].set_visible(False)
ax.spines['top'].set_visible(False)
plt.tight_layout()
plt.legend(fontsize=16)
plt.show()

# ====================== Section 5: Estimating Breathing rate ============================================================prominences = signal.peak_prominences(yhat, peaks)[0]
BR = 60 / (np.diff(peaks[::2]) / SR1)  # fine-tunning needed
BR = int(np.round(np.mean(BR)))
print('breathing rate is ' + str(BR) + ' times per minute')
print('True breathing rate is ' + str(tur) + ' times per minute')
print('Error rate in terms of MAE is ' + str(abs(BR-tur)))
error_rate = abs(BR - tur) / tur * 100
print('Error rate in terms of MAPE is ' + str(error_rate))